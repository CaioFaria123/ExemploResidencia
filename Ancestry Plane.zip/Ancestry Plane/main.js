//Zoom
var zoom_level = 1;

$('#zoomIn').click(function() {
    zoom("in");
});

$('#zoomOut').click(function() {
    zoom("out");
});

function zoom(scale) {

    if (scale === "in") {
        zoom_level = zoom_level + .1;
    }
    if (scale === "out") {
        zoom_level = zoom_level - .1;
    }
    $('#main').css('transform', 'scale(' + zoom_level + ')');
    $('#main').css('-webkit-transform', 'scale(' + zoom_level + ')');
    $('#main').css('-webkit-transform-origin', '0 0');
    $('#main').css('-moz-transform', 'scale(' + zoom_level + ')');
    $('#main').css('-moz-transform-origin', '0 0');
    $('#main').css('-o-transform', 'scale(' + zoom_level + ')');
    $('#main').css('-o-transform-origin', '0 0');
    $('#main').css('-ms-transform', 'scale(' + zoom_level + ')');
    $('#main').css('-ms-transform-origin', '0 0');

}

//SearchBar

$('#searchButton').click(function() {

    var str = $("#searchField").val();
    var strFound;

    if (window.find) {

        strFound = self.find(str);
        if (strFound && self.getSelection && !self.getSelection().anchorNode) {
            strFound = self.find(str)
        }
        if (!strFound) {
            strFound = self.find(str, 0, 1)
            while (self.find(str, 0, 1)) continue
        }
    }
});

//Exit menu and go to tree

$('#btnGenerate').click(function() {

    $('#menu').fadeOut();
    $('#main').fadeIn();
    $('#searchBar').fadeIn();

});

//Open and close tree branch

$('#main').on('click', 'a', function() {

    var node = $(this);
    var branch = $(node).siblings('ul');

    if (node.hasClass('closed')) {

        node.removeClass('closed');
        node.removeAttr('style');

        $(branch).fadeIn();

    } else {

        node.addClass('closed');
        node.attr('style', 'color:red; border-color:red;');

        $(branch).fadeOut();
    }
});

//Obtain tree data

$(document).ready(function() {

    var header = [];
    var data = [];

    if (window.File && window.FileReader && window.FileList && window.Blob) {

        var fileSelected = document.getElementById('readfile');

        fileSelected.addEventListener('change', function(e) {

            var fileExtension = /text.*/;
            var fileTobeRead = fileSelected.files[0];

            if (fileTobeRead.type.match(fileExtension)) {
                var fileReader = new FileReader();
                fileReader.onload = function(e) {
                    var fileContents = document.getElementById('filecontents');
                    console.log(fileReader.result);
                }
                fileReader.readAsText(fileTobeRead);
            } else {
                alert("Please select text file");
            }

        }, false);
    } else {
        alert("Files are not supported");
    }


});

//Tree main generator

function generateTree() {


}