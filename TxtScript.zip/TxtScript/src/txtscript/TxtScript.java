package txtscript;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;


public class TxtScript {

    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException, IOException {

        Scanner scanner = new Scanner(System.in);
        String folderPath = scanner.nextLine();
        File folder = new File(folderPath);
        File[] listOfFiles = folder.listFiles();

        try (PrintWriter writer = new PrintWriter("result.txt", "UTF-8")) {

            for (int i = 0; i < listOfFiles.length; i++) {

                if (listOfFiles[i].isFile()) {

                    System.out.println("File " + listOfFiles[i].getName());

                    if ((listOfFiles[i].getName()).contains("_MAT")) {

                        String path = folderPath + "\\" + listOfFiles[i].getName();

                        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
                            StringBuilder sb = new StringBuilder();
                            String line = br.readLine();

                            while (line != null) {
                                sb.append(line);
                                sb.append(System.lineSeparator());
                                line = br.readLine();
                            }
                            String everything = sb.toString();
                            writer.print(everything);
                        }
                    }
                } else if (listOfFiles[i].isDirectory()) {

                    System.out.println("Directory " + listOfFiles[i].getName());
                }
            }
        }
    }
}
