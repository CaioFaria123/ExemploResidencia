﻿namespace ExemploResidencia
{
    partial class TelaInicial
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbltitulo = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.txtTipo1Id = new System.Windows.Forms.TextBox();
            this.grpbxPesqId = new System.Windows.Forms.GroupBox();
            this.btnPesq = new System.Windows.Forms.Button();
            this.dgvId = new System.Windows.Forms.DataGridView();
            this.grpBoxArray = new System.Windows.Forms.GroupBox();
            this.btnIdArray = new System.Windows.Forms.Button();
            this.grvIdArray = new System.Windows.Forms.DataGridView();
            this.lblIdArray = new System.Windows.Forms.Label();
            this.txtTipoIdArray = new System.Windows.Forms.TextBox();
            this.grpbxPesqId.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvId)).BeginInit();
            this.grpBoxArray.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grvIdArray)).BeginInit();
            this.SuspendLayout();
            // 
            // lbltitulo
            // 
            this.lbltitulo.AutoSize = true;
            this.lbltitulo.Location = new System.Drawing.Point(12, 9);
            this.lbltitulo.Name = "lbltitulo";
            this.lbltitulo.Size = new System.Drawing.Size(103, 13);
            this.lbltitulo.TabIndex = 0;
            this.lbltitulo.Text = "Exemplo Residência";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(6, 45);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(21, 13);
            this.lblId.TabIndex = 2;
            this.lblId.Text = "ID:";
            // 
            // txtTipo1Id
            // 
            this.txtTipo1Id.Location = new System.Drawing.Point(33, 42);
            this.txtTipo1Id.Name = "txtTipo1Id";
            this.txtTipo1Id.Size = new System.Drawing.Size(115, 20);
            this.txtTipo1Id.TabIndex = 3;
            // 
            // grpbxPesqId
            // 
            this.grpbxPesqId.Controls.Add(this.btnPesq);
            this.grpbxPesqId.Controls.Add(this.dgvId);
            this.grpbxPesqId.Controls.Add(this.lblId);
            this.grpbxPesqId.Controls.Add(this.txtTipo1Id);
            this.grpbxPesqId.Location = new System.Drawing.Point(15, 40);
            this.grpbxPesqId.Name = "grpbxPesqId";
            this.grpbxPesqId.Size = new System.Drawing.Size(927, 177);
            this.grpbxPesqId.TabIndex = 4;
            this.grpbxPesqId.TabStop = false;
            this.grpbxPesqId.Text = "Pesquisa por ID";
            // 
            // btnPesq
            // 
            this.btnPesq.Location = new System.Drawing.Point(33, 69);
            this.btnPesq.Name = "btnPesq";
            this.btnPesq.Size = new System.Drawing.Size(115, 23);
            this.btnPesq.TabIndex = 6;
            this.btnPesq.Text = "Pesquisar";
            this.btnPesq.UseVisualStyleBackColor = true;
            this.btnPesq.Click += new System.EventHandler(this.btnPesq_Click);
            // 
            // dgvId
            // 
            this.dgvId.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvId.Location = new System.Drawing.Point(170, 19);
            this.dgvId.Name = "dgvId";
            this.dgvId.Size = new System.Drawing.Size(751, 150);
            this.dgvId.TabIndex = 5;
            // 
            // grpBoxArray
            // 
            this.grpBoxArray.Controls.Add(this.btnIdArray);
            this.grpBoxArray.Controls.Add(this.grvIdArray);
            this.grpBoxArray.Controls.Add(this.lblIdArray);
            this.grpBoxArray.Controls.Add(this.txtTipoIdArray);
            this.grpBoxArray.Location = new System.Drawing.Point(15, 259);
            this.grpBoxArray.Name = "grpBoxArray";
            this.grpBoxArray.Size = new System.Drawing.Size(927, 177);
            this.grpBoxArray.TabIndex = 7;
            this.grpBoxArray.TabStop = false;
            this.grpBoxArray.Text = "Pesquisa por ID Array";
            // 
            // btnIdArray
            // 
            this.btnIdArray.Location = new System.Drawing.Point(9, 69);
            this.btnIdArray.Name = "btnIdArray";
            this.btnIdArray.Size = new System.Drawing.Size(139, 23);
            this.btnIdArray.TabIndex = 6;
            this.btnIdArray.Text = "Pesquisar todos (1 a ID)";
            this.btnIdArray.UseVisualStyleBackColor = true;
            this.btnIdArray.Click += new System.EventHandler(this.btnIdArray_Click);
            // 
            // grvIdArray
            // 
            this.grvIdArray.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grvIdArray.Location = new System.Drawing.Point(170, 19);
            this.grvIdArray.Name = "grvIdArray";
            this.grvIdArray.Size = new System.Drawing.Size(751, 150);
            this.grvIdArray.TabIndex = 5;
            // 
            // lblIdArray
            // 
            this.lblIdArray.AutoSize = true;
            this.lblIdArray.Location = new System.Drawing.Point(6, 45);
            this.lblIdArray.Name = "lblIdArray";
            this.lblIdArray.Size = new System.Drawing.Size(21, 13);
            this.lblIdArray.TabIndex = 2;
            this.lblIdArray.Text = "ID:";
            // 
            // txtTipoIdArray
            // 
            this.txtTipoIdArray.Location = new System.Drawing.Point(33, 42);
            this.txtTipoIdArray.Name = "txtTipoIdArray";
            this.txtTipoIdArray.Size = new System.Drawing.Size(115, 20);
            this.txtTipoIdArray.TabIndex = 3;
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 587);
            this.Controls.Add(this.grpBoxArray);
            this.Controls.Add(this.grpbxPesqId);
            this.Controls.Add(this.lbltitulo);
            this.Name = "TelaInicial";
            this.Text = "Exemplo Residencia";
            this.grpbxPesqId.ResumeLayout(false);
            this.grpbxPesqId.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvId)).EndInit();
            this.grpBoxArray.ResumeLayout(false);
            this.grpBoxArray.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grvIdArray)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbltitulo;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtTipo1Id;
        private System.Windows.Forms.GroupBox grpbxPesqId;
        private System.Windows.Forms.DataGridView dgvId;
        private System.Windows.Forms.Button btnPesq;
        private System.Windows.Forms.GroupBox grpBoxArray;
        private System.Windows.Forms.Button btnIdArray;
        private System.Windows.Forms.DataGridView grvIdArray;
        private System.Windows.Forms.Label lblIdArray;
        private System.Windows.Forms.TextBox txtTipoIdArray;
    }
}

