﻿namespace ExemploResidencia
{
    partial class TelaInicial
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbltitulo = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.txtTipo1Id = new System.Windows.Forms.TextBox();
            this.grpbxPesqId = new System.Windows.Forms.GroupBox();
            this.btnPesq = new System.Windows.Forms.Button();
            this.dgvId = new System.Windows.Forms.DataGridView();
            this.grpbxPesqId.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvId)).BeginInit();
            this.SuspendLayout();
            // 
            // lbltitulo
            // 
            this.lbltitulo.AutoSize = true;
            this.lbltitulo.Location = new System.Drawing.Point(12, 9);
            this.lbltitulo.Name = "lbltitulo";
            this.lbltitulo.Size = new System.Drawing.Size(103, 13);
            this.lbltitulo.TabIndex = 0;
            this.lbltitulo.Text = "Exemplo Residência";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(6, 45);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(21, 13);
            this.lblId.TabIndex = 2;
            this.lblId.Text = "ID:";
            // 
            // txtTipo1Id
            // 
            this.txtTipo1Id.Location = new System.Drawing.Point(33, 42);
            this.txtTipo1Id.Name = "txtTipo1Id";
            this.txtTipo1Id.Size = new System.Drawing.Size(115, 20);
            this.txtTipo1Id.TabIndex = 3;
            // 
            // grpbxPesqId
            // 
            this.grpbxPesqId.Controls.Add(this.btnPesq);
            this.grpbxPesqId.Controls.Add(this.dgvId);
            this.grpbxPesqId.Controls.Add(this.lblId);
            this.grpbxPesqId.Controls.Add(this.txtTipo1Id);
            this.grpbxPesqId.Location = new System.Drawing.Point(15, 40);
            this.grpbxPesqId.Name = "grpbxPesqId";
            this.grpbxPesqId.Size = new System.Drawing.Size(927, 177);
            this.grpbxPesqId.TabIndex = 4;
            this.grpbxPesqId.TabStop = false;
            this.grpbxPesqId.Text = "Pesquisa por ID";
            // 
            // btnPesq
            // 
            this.btnPesq.Location = new System.Drawing.Point(33, 69);
            this.btnPesq.Name = "btnPesq";
            this.btnPesq.Size = new System.Drawing.Size(115, 23);
            this.btnPesq.TabIndex = 6;
            this.btnPesq.Text = "Pesquisar";
            this.btnPesq.UseVisualStyleBackColor = true;
            this.btnPesq.Click += new System.EventHandler(this.btnPesq_Click);
            // 
            // dgvId
            // 
            this.dgvId.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvId.Location = new System.Drawing.Point(170, 19);
            this.dgvId.Name = "dgvId";
            this.dgvId.Size = new System.Drawing.Size(751, 150);
            this.dgvId.TabIndex = 5;
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 587);
            this.Controls.Add(this.grpbxPesqId);
            this.Controls.Add(this.lbltitulo);
            this.Name = "TelaInicial";
            this.Text = "Form1";
            this.grpbxPesqId.ResumeLayout(false);
            this.grpbxPesqId.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvId)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbltitulo;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtTipo1Id;
        private System.Windows.Forms.GroupBox grpbxPesqId;
        private System.Windows.Forms.DataGridView dgvId;
        private System.Windows.Forms.Button btnPesq;
    }
}

